function f() {
    var lenkertyps = java.GET.ProductController.lenkertyp();

}