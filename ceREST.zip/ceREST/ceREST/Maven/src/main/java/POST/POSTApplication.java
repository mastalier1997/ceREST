package POST;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class POSTApplication {
    public static void main(String[] args) {

        SpringApplication.run(POSTApplication.class, args);
    }
}
